<?php
// Allow from any origin
header("Access-Control-Allow-Origin: *");
// Allow specific HTTP methods
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
// Allow specific headers
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = htmlspecialchars(strip_tags($_POST['fullName']));
    $phone = htmlspecialchars(strip_tags($_POST['phone']));
    $email = htmlspecialchars(strip_tags($_POST['email']));
    $message = htmlspecialchars(strip_tags($_POST['message']));

    // Your email address where the form data will be sent
    $to = "merudavilzz@gmail.com"; // Replace with your email address
    $subject = "New Contact Form Submission";
    
    // Email body
    $body = "You have received a new message from the contact form.\n\n".
            "Full Name: $fullName\n".
            "Phone: $phone\n".
            "Email: $email\n".
            "Message: \n$message";

    // Email headers
    $headers = "From: noreply@yourdomain.com\n"; // Replace with your domain
    $headers .= "Reply-To: $email";

    // Send email
    if (mail($to, $subject, $body, $headers)) {
        echo 'success';
    } else {
        echo 'Email sending failed.';
    }
} else {
    echo 'Invalid request.';
}
?>